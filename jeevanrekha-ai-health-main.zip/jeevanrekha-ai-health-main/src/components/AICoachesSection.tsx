import { motion } from 'framer-motion';
import { 
  Heart, Brain, Apple, Bone, Stethoscope, Baby, 
  User, Users, Leaf, Sun, Moon, Activity, ArrowRight 
} from 'lucide-react';

const coaches = [
  {
    name: 'General Wellness Coach',
    description: 'Preventive • Personalized • Advisory',
    icon: Stethoscope,
    color: '#0d9488',
    bgGradient: 'from-teal-500/20 to-cyan-500/20',
  },
  {
    name: 'Cardio Wellness Coach',
    description: 'Preventive • Personalized • Advisory',
    icon: Heart,
    color: '#ef4444',
    bgGradient: 'from-red-500/20 to-pink-500/20',
  },
  {
    name: 'Metabolic Health Coach',
    description: 'Preventive • Personalized • Advisory',
    icon: Activity,
    color: '#22c55e',
    bgGradient: 'from-green-500/20 to-emerald-500/20',
  },
  {
    name: 'Mental Wellness Coach',
    description: 'Preventive • Personalized • Advisory',
    icon: Brain,
    color: '#a855f7',
    bgGradient: 'from-purple-500/20 to-violet-500/20',
  },
  {
    name: 'Musculoskeletal Coach',
    description: 'Preventive • Personalized • Advisory',
    icon: Bone,
    color: '#f97316',
    bgGradient: 'from-orange-500/20 to-amber-500/20',
  },
  {
    name: 'Nutrition & Lifestyle Coach',
    description: 'Preventive • Personalized • Advisory',
    icon: Apple,
    color: '#84cc16',
    bgGradient: 'from-lime-500/20 to-green-500/20',
  },
];

const advancedCoaches = [
  { name: "Women's Health Coach", icon: User, color: '#ec4899', bgGradient: 'from-pink-500/20 to-rose-500/20' },
  { name: 'Senior Health Coach', icon: Users, color: '#f59e0b', bgGradient: 'from-amber-500/20 to-yellow-500/20' },
  { name: 'Pediatric Wellness Coach', icon: Baby, color: '#0ea5e9', bgGradient: 'from-sky-500/20 to-blue-500/20' },
  { name: 'Sleep & Recovery Coach', icon: Moon, color: '#6366f1', bgGradient: 'from-indigo-500/20 to-violet-500/20' },
  { name: 'Holistic Wellness Coach', icon: Leaf, color: '#10b981', bgGradient: 'from-emerald-500/20 to-teal-500/20' },
  { name: 'Energy & Vitality Coach', icon: Sun, color: '#eab308', bgGradient: 'from-yellow-500/20 to-orange-500/20' },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30, scale: 0.9 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.5, type: 'spring' as const, stiffness: 100 },
  },
};

const AICoachesSection = () => {
  return (
    <section id="coaches" className="py-28 bg-gradient-to-b from-health-sky/50 via-health-mint/30 to-background relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-health-cyan/5 rounded-full blur-3xl" />
      
      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <motion.span 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-block px-5 py-2 rounded-full bg-gradient-to-r from-primary/15 to-health-cyan/15 border border-primary/30 text-primary text-sm font-semibold mb-6"
          >
            AI Health Advisory Hub
          </motion.span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-5">
            Meet Your AI{' '}
            <span className="gradient-text">Health Coaches</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Our specialized AI coaches are trained on evidence-based medical knowledge to 
            provide personalized guidance for every aspect of your health journey.
          </p>
        </motion.div>

        {/* Essential Core Agents */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-14"
        >
          <motion.h3 
            className="text-center text-sm font-bold uppercase tracking-wider text-muted-foreground mb-10"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            Essential Core Agents
          </motion.h3>
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-5"
          >
            {coaches.map((coach, index) => (
              <motion.div
                key={coach.name}
                variants={itemVariants}
                whileHover={{ 
                  y: -10, 
                  scale: 1.02,
                  transition: { type: 'spring', stiffness: 300 }
                }}
                className="group relative"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${coach.bgGradient} rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
                <div className="relative glass-card rounded-2xl p-6 cursor-pointer border border-transparent group-hover:border-primary/30 transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <motion.div 
                      className={`p-4 rounded-xl bg-gradient-to-br ${coach.bgGradient}`}
                      whileHover={{ rotate: [0, -10, 10, 0], scale: 1.1 }}
                      transition={{ duration: 0.5 }}
                    >
                      <coach.icon className="w-7 h-7" style={{ color: coach.color }} />
                    </motion.div>
                    <div className="flex-1">
                      <h4 className="font-display font-semibold text-lg mb-1.5 group-hover:text-primary transition-colors">
                        {coach.name}
                      </h4>
                      <p className="text-sm text-muted-foreground">{coach.description}</p>
                    </div>
                    <motion.div
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                      initial={{ x: -10 }}
                      whileHover={{ x: 0 }}
                    >
                      <ArrowRight className="w-5 h-5 text-primary" />
                    </motion.div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        {/* Advanced Expansion Agents */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <motion.h3 
            className="text-center text-sm font-bold uppercase tracking-wider text-muted-foreground mb-10"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            Advanced Expansion Agents
          </motion.h3>
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4"
          >
            {advancedCoaches.map((coach) => (
              <motion.div
                key={coach.name}
                variants={itemVariants}
                whileHover={{ y: -8, scale: 1.05 }}
                className="group"
              >
                <div className="glass-card rounded-xl p-5 text-center cursor-pointer group-hover:shadow-xl transition-all duration-300 border border-transparent group-hover:border-primary/20">
                  <motion.div 
                    className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${coach.bgGradient} mb-3`}
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <coach.icon className="w-6 h-6" style={{ color: coach.color }} />
                  </motion.div>
                  <p className="text-sm font-medium group-hover:text-primary transition-colors leading-tight">
                    {coach.name}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-14"
        >
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: '0 20px 40px -10px hsl(var(--primary) / 0.4)' }}
            whileTap={{ scale: 0.98 }}
            className="inline-flex items-center gap-3 px-8 py-4 rounded-full bg-gradient-to-r from-primary to-health-cyan text-primary-foreground font-semibold shadow-lg transition-shadow"
          >
            <Activity className="w-5 h-5" />
            Explore All AI Coaches
            <ArrowRight className="w-5 h-5" />
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

export default AICoachesSection;
