import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, Heart, Sparkles, Star, Shield } from 'lucide-react';

const CTASection = () => {
  const floatingElements = [
    { icon: Star, x: '10%', y: '20%', delay: 0 },
    { icon: Heart, x: '85%', y: '30%', delay: 0.5 },
    { icon: Shield, x: '15%', y: '70%', delay: 1 },
    { icon: Sparkles, x: '80%', y: '75%', delay: 1.5 },
  ];

  return (
    <section className="py-28 bg-background relative overflow-hidden">
      {/* Decorative Gradient Blobs */}
      <motion.div 
        className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-gradient-to-r from-primary/10 to-health-cyan/10 rounded-full blur-3xl"
        animate={{ 
          scale: [1, 1.2, 1],
          x: [0, 50, 0],
        }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div 
        className="absolute bottom-0 right-1/4 w-[400px] h-[400px] bg-gradient-to-r from-health-cyan/10 to-accent/10 rounded-full blur-3xl"
        animate={{ 
          scale: [1, 1.1, 1],
          x: [0, -30, 0],
        }}
        transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
      />

      {/* Floating Icons */}
      {floatingElements.map(({ icon: Icon, x, y, delay }, index) => (
        <motion.div
          key={index}
          className="absolute hidden md:block"
          style={{ left: x, top: y }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 0.2 }}
          viewport={{ once: true }}
        >
          <motion.div
            animate={{ 
              y: [0, -20, 0],
              rotate: [0, 10, -10, 0],
            }}
            transition={{ duration: 5, repeat: Infinity, delay }}
            className="p-3 rounded-xl bg-primary/10 backdrop-blur-sm"
          >
            <Icon className="w-6 h-6 text-primary" />
          </motion.div>
        </motion.div>
      ))}

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="max-w-4xl mx-auto text-center"
        >
          {/* Animated Badge */}
          <motion.div
            className="inline-flex items-center gap-2 mb-8"
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            transition={{ type: 'spring', stiffness: 200 }}
          >
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              <Heart className="w-6 h-6 text-accent" />
            </motion.div>
            <span className="text-accent font-semibold">Your Health Journey Starts Here</span>
          </motion.div>

          <motion.h2 
            className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            Ready to Transform Your{' '}
            <motion.span 
              className="gradient-text inline-block"
              animate={{ 
                backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
              }}
              transition={{ duration: 5, repeat: Infinity, ease: 'linear' }}
              style={{
                backgroundSize: '200% 200%',
                backgroundImage: 'linear-gradient(90deg, hsl(var(--primary)), hsl(var(--health-cyan)), hsl(var(--primary)))',
              }}
            >
              Health Journey?
            </motion.span>
          </motion.h2>

          <motion.p 
            className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            Join thousands of users who have already discovered the power of AI-driven 
            health guidance. Start your free trial today and experience personalized 
            healthcare like never before.
          </motion.p>

          <motion.div 
            className="flex flex-col sm:flex-row gap-5 justify-center items-center mb-10"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
          >
            <motion.div 
              whileHover={{ scale: 1.05 }} 
              whileTap={{ scale: 0.98 }}
            >
              <Button variant="hero" size="xl" className="group min-w-[220px] shadow-xl shadow-primary/30">
                Get Started Free
                <motion.span
                  animate={{ x: [0, 5, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  <ArrowRight className="w-5 h-5" />
                </motion.span>
              </Button>
            </motion.div>
            <motion.div 
              whileHover={{ scale: 1.05 }} 
              whileTap={{ scale: 0.98 }}
            >
              <Button variant="outline" size="xl" className="min-w-[220px] group">
                <Sparkles className="w-5 h-5 group-hover:text-primary transition-colors" />
                Book a Demo
              </Button>
            </motion.div>
          </motion.div>

          {/* Trust Indicators */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="flex flex-wrap justify-center gap-6 text-sm text-muted-foreground"
          >
            {['No credit card required', 'Free 14-day trial', 'Cancel anytime'].map((text, i) => (
              <motion.div 
                key={text}
                className="flex items-center gap-2"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5 + i * 0.1 }}
              >
                <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                <span>{text}</span>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection;
