import { motion } from 'framer-motion';
import { 
  Shield, Zap, Clock, MessageSquare, 
  FileText, Video, Bell, Lock, CheckCircle2 
} from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Evidence-Based Guidance',
    description: 'All recommendations are backed by peer-reviewed medical research and clinical guidelines.',
    gradient: 'from-primary to-health-cyan',
    delay: 0,
  },
  {
    icon: Zap,
    title: 'Instant AI Response',
    description: 'Get immediate answers to your health queries with our 24/7 AI-powered system.',
    gradient: 'from-amber-500 to-orange-500',
    delay: 0.1,
  },
  {
    icon: Clock,
    title: '24/7 Availability',
    description: 'Access personalized health coaching anytime, anywhere, on any device.',
    gradient: 'from-blue-500 to-cyan-500',
    delay: 0.2,
  },
  {
    icon: MessageSquare,
    title: 'Natural Conversations',
    description: 'Chat naturally with AI coaches that understand context and follow-up questions.',
    gradient: 'from-purple-500 to-pink-500',
    delay: 0.3,
  },
  {
    icon: FileText,
    title: 'Health Reports',
    description: 'Generate detailed health reports and track your progress over time.',
    gradient: 'from-green-500 to-emerald-500',
    delay: 0.4,
  },
  {
    icon: Video,
    title: 'Expert Consultations',
    description: 'Connect with real healthcare professionals when you need human expertise.',
    gradient: 'from-red-500 to-rose-500',
    delay: 0.5,
  },
  {
    icon: Bell,
    title: 'Smart Reminders',
    description: 'Never miss medications, appointments, or health check-ups with intelligent alerts.',
    gradient: 'from-indigo-500 to-violet-500',
    delay: 0.6,
  },
  {
    icon: Lock,
    title: 'Privacy First',
    description: 'Your health data is encrypted and protected with enterprise-grade security.',
    gradient: 'from-slate-600 to-slate-800',
    delay: 0.7,
  },
];

const FeaturesSection = () => {
  return (
    <section id="features" className="py-28 bg-gradient-to-b from-background via-health-mint/20 to-background relative overflow-hidden">
      {/* Animated Background Blobs */}
      <motion.div 
        className="absolute top-1/4 -left-32 w-96 h-96 bg-primary/5 rounded-full blur-3xl"
        animate={{ 
          x: [0, 50, 0],
          y: [0, 30, 0],
        }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div 
        className="absolute bottom-1/4 -right-32 w-96 h-96 bg-health-cyan/5 rounded-full blur-3xl"
        animate={{ 
          x: [0, -50, 0],
          y: [0, -30, 0],
        }}
        transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
      />

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.span 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-gradient-to-r from-primary/15 to-health-cyan/15 border border-primary/30 text-primary text-sm font-semibold mb-6"
          >
            <CheckCircle2 className="w-4 h-4" />
            Why Choose Jeevanrekha
          </motion.span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-5">
            Features That{' '}
            <span className="gradient-text">Empower You</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Experience the future of healthcare with our comprehensive suite of 
            AI-powered features designed for your wellbeing.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: feature.delay }}
              whileHover={{ y: -12 }}
              className="group"
            >
              <div className="glass-card rounded-2xl p-7 h-full cursor-pointer relative overflow-hidden border-2 border-transparent group-hover:border-primary/20 transition-all duration-500">
                {/* Glow Effect on Hover */}
                <motion.div
                  className={`absolute -top-20 -right-20 w-40 h-40 bg-gradient-to-br ${feature.gradient} rounded-full blur-3xl opacity-0 group-hover:opacity-30 transition-opacity duration-500`}
                />
                
                {/* Icon */}
                <motion.div
                  className={`relative z-10 w-16 h-16 rounded-xl bg-gradient-to-r ${feature.gradient} flex items-center justify-center mb-5 shadow-lg`}
                  whileHover={{ 
                    scale: 1.1, 
                    rotate: [0, -5, 5, 0],
                  }}
                  transition={{ type: 'spring', stiffness: 300 }}
                >
                  <feature.icon className="w-8 h-8 text-white" />
                </motion.div>
                
                {/* Content */}
                <h3 className="relative z-10 font-display font-semibold text-xl mb-3 group-hover:text-primary transition-colors">
                  {feature.title}
                </h3>
                <p className="relative z-10 text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>

                {/* Hover Line */}
                <motion.div
                  className={`absolute bottom-0 left-0 h-1 bg-gradient-to-r ${feature.gradient}`}
                  initial={{ width: 0 }}
                  whileHover={{ width: '100%' }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
