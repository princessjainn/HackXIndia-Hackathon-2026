import { motion } from 'framer-motion';
import { 
  Pill, Heart, Stethoscope, Bone, Apple, Brain, 
  Baby, Eye, Ear, Hand, Sparkles 
} from 'lucide-react';

const conditions = [
  { name: 'Diabetes Care', icon: Pill, color: '#f97316', bg: 'from-orange-500/15 to-amber-500/15' },
  { name: 'Cardiac Care', icon: Heart, color: '#ef4444', bg: 'from-red-500/15 to-rose-500/15' },
  { name: 'Digestive Health', icon: Stethoscope, color: '#eab308', bg: 'from-yellow-500/15 to-lime-500/15' },
  { name: 'Pain Relief', icon: Hand, color: '#8b5cf6', bg: 'from-violet-500/15 to-purple-500/15' },
  { name: 'Bone & Joint', icon: Bone, color: '#06b6d4', bg: 'from-cyan-500/15 to-teal-500/15' },
  { name: 'Nutrition', icon: Apple, color: '#22c55e', bg: 'from-green-500/15 to-emerald-500/15' },
  { name: 'Mental Health', icon: Brain, color: '#a855f7', bg: 'from-purple-500/15 to-pink-500/15' },
  { name: 'Child Health', icon: Baby, color: '#ec4899', bg: 'from-pink-500/15 to-rose-500/15' },
  { name: 'Eye Care', icon: Eye, color: '#3b82f6', bg: 'from-blue-500/15 to-indigo-500/15' },
  { name: 'Ear Care', icon: Ear, color: '#14b8a6', bg: 'from-teal-500/15 to-cyan-500/15' },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.06,
      delayChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, scale: 0.8, rotateY: -30 },
  visible: {
    opacity: 1,
    scale: 1,
    rotateY: 0,
    transition: { duration: 0.5, type: 'spring' as const, stiffness: 120 },
  },
};

const HealthConditionsSection = () => {
  return (
    <section id="conditions" className="py-28 bg-background relative overflow-hidden">
      {/* Subtle Background Pattern */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 1px 1px, hsl(var(--primary)) 1px, transparent 0)',
          backgroundSize: '40px 40px',
        }} />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            transition={{ type: 'spring', stiffness: 200 }}
            className="inline-flex items-center gap-2 mb-6"
          >
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="text-sm font-semibold text-primary uppercase tracking-wider">Specialized Care</span>
          </motion.div>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-5">
            Browse by{' '}
            <span className="gradient-text">Health Conditions</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Find specialized AI guidance for your specific health concerns. 
            Our coaches are trained to address a wide range of conditions.
          </p>
        </motion.div>

        {/* Conditions Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5"
        >
          {conditions.map((condition, index) => (
            <motion.div
              key={condition.name}
              variants={itemVariants}
              whileHover={{ 
                y: -12, 
                scale: 1.05,
                boxShadow: '0 25px 50px -12px rgba(0,0,0,0.15)',
              }}
              whileTap={{ scale: 0.98 }}
              className="group"
            >
              <div className="glass-card rounded-2xl p-6 flex flex-col items-center text-center cursor-pointer h-full border-2 border-transparent group-hover:border-primary/30 transition-all duration-300 relative overflow-hidden">
                {/* Animated Background */}
                <motion.div
                  className={`absolute inset-0 bg-gradient-to-br ${condition.bg} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
                />
                
                {/* Icon Container */}
                <motion.div
                  className={`relative z-10 w-16 h-16 rounded-2xl flex items-center justify-center mb-4 bg-gradient-to-br ${condition.bg}`}
                  whileHover={{ 
                    rotate: [0, -10, 10, -5, 5, 0],
                    scale: 1.15,
                  }}
                  transition={{ duration: 0.6 }}
                >
                  <motion.div
                    animate={{ 
                      scale: [1, 1.1, 1],
                    }}
                    transition={{ 
                      duration: 2, 
                      repeat: Infinity,
                      delay: index * 0.2,
                    }}
                  >
                    <condition.icon
                      className="w-8 h-8"
                      style={{ color: condition.color }}
                    />
                  </motion.div>
                </motion.div>
                
                <h3 className="relative z-10 font-semibold text-foreground group-hover:text-primary transition-colors">
                  {condition.name}
                </h3>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* View All Link */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="text-center mt-12"
        >
          <motion.a
            href="#"
            className="inline-flex items-center gap-2 text-primary font-semibold group"
            whileHover={{ scale: 1.05 }}
          >
            View all health conditions
            <motion.span
              animate={{ x: [0, 6, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="group-hover:text-health-cyan transition-colors"
            >
              →
            </motion.span>
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
};

export default HealthConditionsSection;
