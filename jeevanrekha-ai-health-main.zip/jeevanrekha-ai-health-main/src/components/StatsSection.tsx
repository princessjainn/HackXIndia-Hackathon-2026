import { motion, useMotionValue, useTransform, animate, useInView } from 'framer-motion';
import { useEffect, useState, useRef } from 'react';
import { Users, MessageSquare, Award, Clock, TrendingUp } from 'lucide-react';

const stats = [
  { 
    icon: Users, 
    value: 50000, 
    suffix: '+',
    label: 'Active Users',
    description: 'Trust our platform',
  },
  { 
    icon: MessageSquare, 
    value: 2, 
    suffix: 'M+',
    label: 'Health Queries',
    description: 'Answered accurately',
  },
  { 
    icon: Award, 
    value: 98, 
    suffix: '%',
    label: 'Satisfaction Rate',
    description: 'User happiness score',
  },
  { 
    icon: Clock, 
    value: 24, 
    suffix: '/7',
    label: 'Always Available',
    description: 'Round-the-clock support',
  },
];

const Counter = ({ value, suffix, inView }: { value: number; suffix: string; inView: boolean }) => {
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    if (inView) {
      const controls = animate(0, value, {
        duration: 2.5,
        ease: 'easeOut',
        onUpdate: (latest) => setDisplayValue(Math.round(latest)),
      });
      return () => controls.stop();
    }
  }, [value, inView]);

  return (
    <span>
      {displayValue.toLocaleString()}{suffix}
    </span>
  );
};

const StatsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section ref={ref} className="py-24 relative overflow-hidden">
      {/* Animated Gradient Background */}
      <motion.div 
        className="absolute inset-0"
        style={{
          background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--health-cyan)) 50%, hsl(var(--primary)) 100%)',
          backgroundSize: '200% 200%',
        }}
        animate={{
          backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: 'linear',
        }}
      />
      
      {/* Animated Orbs */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-white/10"
            style={{
              width: 100 + Math.random() * 200,
              height: 100 + Math.random() * 200,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -60, 0],
              x: [0, Math.random() * 40 - 20, 0],
              scale: [1, 1.2, 1],
              opacity: [0.1, 0.2, 0.1],
            }}
            transition={{
              duration: 6 + Math.random() * 4,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: Math.random() * 3,
            }}
          />
        ))}
      </div>

      {/* Wave Pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" viewBox="0 0 1200 400" preserveAspectRatio="none">
          <motion.path
            d="M0,200 C300,100 600,300 900,200 C1050,150 1150,250 1200,200 L1200,400 L0,400 Z"
            fill="white"
            animate={{
              d: [
                "M0,200 C300,100 600,300 900,200 C1050,150 1150,250 1200,200 L1200,400 L0,400 Z",
                "M0,200 C300,300 600,100 900,200 C1050,250 1150,150 1200,200 L1200,400 L0,400 Z",
                "M0,200 C300,100 600,300 900,200 C1050,150 1150,250 1200,200 L1200,400 L0,400 Z",
              ]
            }}
            transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
          />
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <motion.div
            className="inline-flex items-center gap-2 text-white/90 mb-4"
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
          >
            <TrendingUp className="w-5 h-5" />
            <span className="text-sm font-semibold uppercase tracking-wider">Our Impact</span>
          </motion.div>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-white">
            Trusted by Thousands Worldwide
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 40, scale: 0.9 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15, type: 'spring' }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="text-center group"
            >
              <motion.div
                className="inline-flex p-5 rounded-2xl bg-white/15 backdrop-blur-sm mb-5 group-hover:bg-white/25 transition-colors duration-300"
                whileHover={{ rotate: [0, -10, 10, 0] }}
                transition={{ duration: 0.5 }}
              >
                <stat.icon className="w-9 h-9 text-white" />
              </motion.div>
              <motion.div
                className="font-display text-5xl md:text-6xl font-bold text-white mb-2"
              >
                <Counter value={stat.value} suffix={stat.suffix} inView={isInView} />
              </motion.div>
              <p className="text-white font-semibold text-lg mb-1">{stat.label}</p>
              <p className="text-white/70 text-sm">{stat.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsSection;
