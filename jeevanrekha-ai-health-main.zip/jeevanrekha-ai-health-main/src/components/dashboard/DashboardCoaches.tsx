import { motion } from 'framer-motion';
import { 
  Heart, Brain, Apple, Bone, Stethoscope, Baby, 
  User, Users, Leaf, Sun, Moon, Activity, ArrowRight, MessageSquare 
} from 'lucide-react';

const coaches = [
  {
    id: 'general-wellness',
    name: 'General Wellness Coach',
    description: 'Preventive • Personalized • Advisory',
    icon: Stethoscope,
    color: '#0d9488',
    bgGradient: 'from-teal-500/20 to-cyan-500/20',
    chatType: 'general' as const,
  },
  {
    id: 'cardio',
    name: 'Cardio Wellness Coach',
    description: 'Heart health & cardiovascular care',
    icon: Heart,
    color: '#ef4444',
    bgGradient: 'from-red-500/20 to-pink-500/20',
    chatType: 'general' as const,
  },
  {
    id: 'metabolic',
    name: 'Metabolic Health Coach',
    description: 'Metabolism & weight management',
    icon: Activity,
    color: '#22c55e',
    bgGradient: 'from-green-500/20 to-emerald-500/20',
    chatType: 'general' as const,
  },
  {
    id: 'mental',
    name: 'Mental Wellness Coach',
    description: 'Mental health & emotional support',
    icon: Brain,
    color: '#a855f7',
    bgGradient: 'from-purple-500/20 to-violet-500/20',
    chatType: 'general' as const,
  },
  {
    id: 'musculoskeletal',
    name: 'Musculoskeletal Coach',
    description: 'Bones, joints & mobility',
    icon: Bone,
    color: '#f97316',
    bgGradient: 'from-orange-500/20 to-amber-500/20',
    chatType: 'general' as const,
  },
  {
    id: 'nutrition',
    name: 'Nutrition & Lifestyle Coach',
    description: 'Diet & healthy living',
    icon: Apple,
    color: '#84cc16',
    bgGradient: 'from-lime-500/20 to-green-500/20',
    chatType: 'general' as const,
  },
];

const advancedCoaches = [
  { id: 'womens-health', name: "Women's Health", icon: User, color: '#ec4899', bgGradient: 'from-pink-500/20 to-rose-500/20' },
  { id: 'senior', name: 'Senior Health', icon: Users, color: '#f59e0b', bgGradient: 'from-amber-500/20 to-yellow-500/20' },
  { id: 'pediatric', name: 'Child Health', icon: Baby, color: '#0ea5e9', bgGradient: 'from-sky-500/20 to-blue-500/20' },
  { id: 'sleep', name: 'Sleep Coach', icon: Moon, color: '#6366f1', bgGradient: 'from-indigo-500/20 to-violet-500/20' },
  { id: 'holistic', name: 'Holistic Wellness', icon: Leaf, color: '#10b981', bgGradient: 'from-emerald-500/20 to-teal-500/20' },
  { id: 'energy', name: 'Energy & Vitality', icon: Sun, color: '#eab308', bgGradient: 'from-yellow-500/20 to-orange-500/20' },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.06 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.4, type: 'spring' as const, stiffness: 100 },
  },
};

interface DashboardCoachesProps {
  onSelectCoach: (coachId: string, coachName: string) => void;
}

const DashboardCoaches = ({ onSelectCoach }: DashboardCoachesProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className="space-y-6"
    >
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-2xl font-bold flex items-center gap-2">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
            >
              <Activity className="w-6 h-6 text-primary" />
            </motion.div>
            AI Health Coaches
          </h2>
          <p className="text-muted-foreground text-sm">Chat with specialized AI coaches for personalized guidance</p>
        </div>
      </div>

      {/* Core Coaches Grid */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid md:grid-cols-2 lg:grid-cols-3 gap-4"
      >
        {coaches.map((coach) => (
          <motion.div
            key={coach.id}
            variants={itemVariants}
            whileHover={{ 
              y: -8, 
              scale: 1.02,
              transition: { type: 'spring', stiffness: 300 }
            }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelectCoach(coach.id, coach.name)}
            className="group relative cursor-pointer"
          >
            <div className={`absolute inset-0 bg-gradient-to-br ${coach.bgGradient} rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
            <div className="relative glass-card rounded-2xl p-5 border border-transparent group-hover:border-primary/30 transition-all duration-300">
              <div className="flex items-start gap-4">
                <motion.div 
                  className={`p-3 rounded-xl bg-gradient-to-br ${coach.bgGradient}`}
                  whileHover={{ rotate: [0, -10, 10, 0], scale: 1.1 }}
                  transition={{ duration: 0.5 }}
                >
                  <coach.icon className="w-6 h-6" style={{ color: coach.color }} />
                </motion.div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-display font-semibold text-base mb-1 group-hover:text-primary transition-colors truncate">
                    {coach.name}
                  </h4>
                  <p className="text-xs text-muted-foreground">{coach.description}</p>
                </div>
                <motion.div
                  className="opacity-0 group-hover:opacity-100 transition-opacity"
                  whileHover={{ x: 3 }}
                >
                  <MessageSquare className="w-4 h-4 text-primary" />
                </motion.div>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Advanced Coaches */}
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4">
          Specialized Coaches
        </h3>
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-3 sm:grid-cols-6 gap-3"
        >
          {advancedCoaches.map((coach) => (
            <motion.div
              key={coach.id}
              variants={itemVariants}
              whileHover={{ y: -6, scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onSelectCoach(coach.id, coach.name)}
              className="group cursor-pointer"
            >
              <div className="glass-card rounded-xl p-4 text-center group-hover:shadow-lg transition-all duration-300 border border-transparent group-hover:border-primary/20">
                <motion.div 
                  className={`inline-flex p-2.5 rounded-xl bg-gradient-to-br ${coach.bgGradient} mb-2`}
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.6 }}
                >
                  <coach.icon className="w-5 h-5" style={{ color: coach.color }} />
                </motion.div>
                <p className="text-xs font-medium group-hover:text-primary transition-colors leading-tight">
                  {coach.name}
                </p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </motion.div>
  );
};

export default DashboardCoaches;
