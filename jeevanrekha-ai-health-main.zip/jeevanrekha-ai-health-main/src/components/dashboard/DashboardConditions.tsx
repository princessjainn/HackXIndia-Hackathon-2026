import { motion } from 'framer-motion';
import { 
  Pill, Heart, Stethoscope, Bone, Apple, Brain, 
  Baby, Eye, Ear, Hand, Sparkles 
} from 'lucide-react';

const conditions = [
  { id: 'diabetes', name: 'Diabetes Care', icon: Pill, color: '#f97316', bg: 'from-orange-500/15 to-amber-500/15' },
  { id: 'cardiac', name: 'Cardiac Care', icon: Heart, color: '#ef4444', bg: 'from-red-500/15 to-rose-500/15' },
  { id: 'digestive', name: 'Digestive Health', icon: Stethoscope, color: '#eab308', bg: 'from-yellow-500/15 to-lime-500/15' },
  { id: 'pain', name: 'Pain Relief', icon: Hand, color: '#8b5cf6', bg: 'from-violet-500/15 to-purple-500/15' },
  { id: 'bone', name: 'Bone & Joint', icon: Bone, color: '#06b6d4', bg: 'from-cyan-500/15 to-teal-500/15' },
  { id: 'nutrition', name: 'Nutrition', icon: Apple, color: '#22c55e', bg: 'from-green-500/15 to-emerald-500/15' },
  { id: 'mental', name: 'Mental Health', icon: Brain, color: '#a855f7', bg: 'from-purple-500/15 to-pink-500/15' },
  { id: 'child', name: 'Child Health', icon: Baby, color: '#ec4899', bg: 'from-pink-500/15 to-rose-500/15' },
  { id: 'eye', name: 'Eye Care', icon: Eye, color: '#3b82f6', bg: 'from-blue-500/15 to-indigo-500/15' },
  { id: 'ear', name: 'Ear Care', icon: Ear, color: '#14b8a6', bg: 'from-teal-500/15 to-cyan-500/15' },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.04, delayChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, scale: 0.8, rotateY: -20 },
  visible: {
    opacity: 1,
    scale: 1,
    rotateY: 0,
    transition: { duration: 0.4, type: 'spring' as const, stiffness: 120 },
  },
};

interface DashboardConditionsProps {
  onSelectCondition: (conditionId: string, conditionName: string) => void;
}

const DashboardConditions = ({ onSelectCondition }: DashboardConditionsProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="space-y-4"
    >
      {/* Section Header */}
      <div className="flex items-center gap-2">
        <motion.div
          animate={{ rotate: [0, 360] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
        >
          <Sparkles className="w-5 h-5 text-primary" />
        </motion.div>
        <h2 className="font-display text-xl font-bold">Health Conditions</h2>
      </div>

      {/* Conditions Grid */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-2 sm:grid-cols-5 gap-3"
      >
        {conditions.map((condition, index) => (
          <motion.div
            key={condition.id}
            variants={itemVariants}
            whileHover={{ 
              y: -8, 
              scale: 1.05,
              boxShadow: '0 20px 40px -12px rgba(0,0,0,0.15)',
            }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelectCondition(condition.id, condition.name)}
            className="group cursor-pointer"
          >
            <div className="glass-card rounded-xl p-4 flex flex-col items-center text-center h-full border-2 border-transparent group-hover:border-primary/30 transition-all duration-300 relative overflow-hidden">
              {/* Animated Background */}
              <motion.div
                className={`absolute inset-0 bg-gradient-to-br ${condition.bg} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
              />
              
              {/* Icon Container */}
              <motion.div
                className={`relative z-10 w-12 h-12 rounded-xl flex items-center justify-center mb-2 bg-gradient-to-br ${condition.bg}`}
                whileHover={{ rotate: [0, -10, 10, 0], scale: 1.1 }}
                transition={{ duration: 0.5 }}
              >
                <motion.div
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: index * 0.15 }}
                >
                  <condition.icon className="w-6 h-6" style={{ color: condition.color }} />
                </motion.div>
              </motion.div>
              
              <h3 className="relative z-10 font-semibold text-sm group-hover:text-primary transition-colors">
                {condition.name}
              </h3>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
};

export default DashboardConditions;
