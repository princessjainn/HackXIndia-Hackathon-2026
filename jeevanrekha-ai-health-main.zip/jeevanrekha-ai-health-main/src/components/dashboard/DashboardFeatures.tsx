import { motion } from 'framer-motion';
import { 
  Shield, Zap, Clock, MessageSquare, 
  FileText, Video, Bell, Lock, CheckCircle2 
} from 'lucide-react';

const features = [
  {
    id: 'evidence',
    icon: Shield,
    title: 'Evidence-Based',
    description: 'Peer-reviewed medical research',
    gradient: 'from-primary to-health-cyan',
  },
  {
    id: 'instant',
    icon: Zap,
    title: 'Instant AI',
    description: '24/7 AI-powered responses',
    gradient: 'from-amber-500 to-orange-500',
  },
  {
    id: 'availability',
    icon: Clock,
    title: '24/7 Available',
    description: 'Access anytime, anywhere',
    gradient: 'from-blue-500 to-cyan-500',
  },
  {
    id: 'conversations',
    icon: MessageSquare,
    title: 'Natural Chat',
    description: 'Context-aware conversations',
    gradient: 'from-purple-500 to-pink-500',
  },
  {
    id: 'reports',
    icon: FileText,
    title: 'Health Reports',
    description: 'Track your progress',
    gradient: 'from-green-500 to-emerald-500',
  },
  {
    id: 'consultations',
    icon: Video,
    title: 'Expert Connect',
    description: 'Real healthcare professionals',
    gradient: 'from-red-500 to-rose-500',
  },
  {
    id: 'reminders',
    icon: Bell,
    title: 'Smart Alerts',
    description: 'Never miss health check-ups',
    gradient: 'from-indigo-500 to-violet-500',
  },
  {
    id: 'privacy',
    icon: Lock,
    title: 'Privacy First',
    description: 'Enterprise-grade security',
    gradient: 'from-slate-600 to-slate-800',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.4, type: 'spring' as const, stiffness: 100 },
  },
};

const DashboardFeatures = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="space-y-4"
    >
      {/* Section Header */}
      <div className="flex items-center gap-2">
        <motion.div
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <CheckCircle2 className="w-5 h-5 text-primary" />
        </motion.div>
        <h2 className="font-display text-xl font-bold">Platform Features</h2>
      </div>

      {/* Features Grid */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-2 lg:grid-cols-4 gap-3"
      >
        {features.map((feature, index) => (
          <motion.div
            key={feature.id}
            variants={itemVariants}
            whileHover={{ y: -6, scale: 1.02 }}
            className="group"
          >
            <div className="glass-card rounded-xl p-4 h-full cursor-pointer relative overflow-hidden border border-transparent group-hover:border-primary/20 transition-all duration-300">
              {/* Glow Effect */}
              <motion.div
                className={`absolute -top-10 -right-10 w-24 h-24 bg-gradient-to-br ${feature.gradient} rounded-full blur-2xl opacity-0 group-hover:opacity-20 transition-opacity duration-500`}
              />
              
              <div className="flex items-start gap-3">
                {/* Icon */}
                <motion.div
                  className={`relative z-10 w-10 h-10 rounded-lg bg-gradient-to-r ${feature.gradient} flex items-center justify-center shadow-md flex-shrink-0`}
                  whileHover={{ scale: 1.1, rotate: [0, -5, 5, 0] }}
                  transition={{ type: 'spring', stiffness: 300 }}
                >
                  <feature.icon className="w-5 h-5 text-white" />
                </motion.div>
                
                {/* Content */}
                <div className="min-w-0">
                  <h3 className="relative z-10 font-display font-semibold text-sm mb-0.5 group-hover:text-primary transition-colors">
                    {feature.title}
                  </h3>
                  <p className="relative z-10 text-xs text-muted-foreground leading-snug">
                    {feature.description}
                  </p>
                </div>
              </div>

              {/* Bottom Line Animation */}
              <motion.div
                className={`absolute bottom-0 left-0 h-0.5 bg-gradient-to-r ${feature.gradient}`}
                initial={{ width: 0 }}
                whileHover={{ width: '100%' }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
};

export default DashboardFeatures;
