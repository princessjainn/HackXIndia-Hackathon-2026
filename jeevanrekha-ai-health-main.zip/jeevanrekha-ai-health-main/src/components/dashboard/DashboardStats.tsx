import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Activity, Clock, Star } from 'lucide-react';

const stats = [
  { icon: Users, value: 50000, suffix: '+', label: 'Users', color: 'text-primary' },
  { icon: Activity, value: 2000000, suffix: '+', label: 'Consultations', color: 'text-green-500' },
  { icon: Clock, value: 24, suffix: '/7', label: 'Available', color: 'text-blue-500' },
  { icon: Star, value: 4.9, suffix: '', label: 'Rating', color: 'text-amber-500', decimals: 1 },
];

const Counter = ({ 
  value, 
  suffix, 
  inView, 
  decimals = 0 
}: { 
  value: number; 
  suffix: string; 
  inView: boolean;
  decimals?: number;
}) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!inView) return;
    
    const duration = 2000;
    const steps = 60;
    const increment = value / steps;
    let current = 0;
    
    const timer = setInterval(() => {
      current += increment;
      if (current >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(current);
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [value, inView]);

  const formatValue = (val: number) => {
    if (decimals > 0) return val.toFixed(decimals);
    if (val >= 1000000) return (val / 1000000).toFixed(1) + 'M';
    if (val >= 1000) return (val / 1000).toFixed(0) + 'K';
    return Math.floor(val).toString();
  };

  return (
    <span className="font-display text-2xl font-bold">
      {formatValue(count)}{suffix}
    </span>
  );
};

const DashboardStats = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="grid grid-cols-2 lg:grid-cols-4 gap-3"
    >
      {stats.map((stat, index) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: index * 0.1 }}
          whileHover={{ y: -4, scale: 1.02 }}
          className="glass-card rounded-xl p-4 text-center relative overflow-hidden group"
        >
          {/* Background glow */}
          <div className={`absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity`} />
          
          <motion.div
            className={`inline-flex p-2 rounded-lg bg-muted mb-2`}
            whileHover={{ rotate: 360 }}
            transition={{ duration: 0.5 }}
          >
            <stat.icon className={`w-5 h-5 ${stat.color}`} />
          </motion.div>
          
          <div className={stat.color}>
            <Counter value={stat.value} suffix={stat.suffix} inView={true} decimals={stat.decimals} />
          </div>
          
          <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
        </motion.div>
      ))}
    </motion.div>
  );
};

export default DashboardStats;
