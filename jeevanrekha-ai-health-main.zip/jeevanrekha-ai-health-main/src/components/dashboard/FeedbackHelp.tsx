import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  MessageCircleQuestion, X, HelpCircle, Bug, 
  Lightbulb, Star, Send, ChevronRight 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

const helpOptions = [
  { id: 'help', icon: HelpCircle, label: 'Get Help', description: 'Learn how to use the app', color: 'text-blue-500' },
  { id: 'bug', icon: Bug, label: 'Report Bug', description: 'Something not working?', color: 'text-red-500' },
  { id: 'idea', icon: Lightbulb, label: 'Suggest Feature', description: 'Share your ideas', color: 'text-amber-500' },
  { id: 'rate', icon: Star, label: 'Rate Us', description: 'Tell us how we did', color: 'text-green-500' },
];

const FeedbackHelp = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [feedback, setFeedback] = useState('');
  const [rating, setRating] = useState(0);
  const { toast } = useToast();

  const handleSubmit = () => {
    toast({
      title: 'Thank you!',
      description: 'Your feedback has been submitted successfully.',
    });
    setFeedback('');
    setRating(0);
    setSelectedOption(null);
    setIsOpen(false);
  };

  const renderContent = () => {
    if (!selectedOption) {
      return (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="space-y-2"
        >
          {helpOptions.map((option, index) => (
            <motion.button
              key={option.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => setSelectedOption(option.id)}
              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-muted transition-colors group text-left"
            >
              <div className={`p-2 rounded-lg bg-muted group-hover:scale-110 transition-transform`}>
                <option.icon className={`w-5 h-5 ${option.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm">{option.label}</p>
                <p className="text-xs text-muted-foreground">{option.description}</p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
            </motion.button>
          ))}
        </motion.div>
      );
    }

    if (selectedOption === 'help') {
      return (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="space-y-4"
        >
          <button 
            onClick={() => setSelectedOption(null)}
            className="text-sm text-primary hover:underline flex items-center gap-1"
          >
            ← Back
          </button>
          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-muted/50">
              <h4 className="font-medium text-sm mb-1">💬 AI Coaches</h4>
              <p className="text-xs text-muted-foreground">Click any coach card to start a conversation about your health concerns.</p>
            </div>
            <div className="p-3 rounded-xl bg-muted/50">
              <h4 className="font-medium text-sm mb-1">🏥 Health Conditions</h4>
              <p className="text-xs text-muted-foreground">Browse conditions to get specialized guidance from our AI.</p>
            </div>
            <div className="p-3 rounded-xl bg-muted/50">
              <h4 className="font-medium text-sm mb-1">📊 Dashboard</h4>
              <p className="text-xs text-muted-foreground">Access all your health data, reports, and history from the sidebar.</p>
            </div>
          </div>
        </motion.div>
      );
    }

    if (selectedOption === 'rate') {
      return (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="space-y-4"
        >
          <button 
            onClick={() => setSelectedOption(null)}
            className="text-sm text-primary hover:underline flex items-center gap-1"
          >
            ← Back
          </button>
          <div className="text-center">
            <p className="text-sm font-medium mb-3">How would you rate your experience?</p>
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <motion.button
                  key={star}
                  whileHover={{ scale: 1.2 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setRating(star)}
                >
                  <Star 
                    className={`w-8 h-8 ${rating >= star ? 'text-amber-400 fill-amber-400' : 'text-muted-foreground'} transition-colors`} 
                  />
                </motion.button>
              ))}
            </div>
            {rating > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4"
              >
                <Button onClick={handleSubmit} className="w-full" size="sm">
                  Submit Rating
                </Button>
              </motion.div>
            )}
          </div>
        </motion.div>
      );
    }

    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="space-y-4"
      >
        <button 
          onClick={() => setSelectedOption(null)}
          className="text-sm text-primary hover:underline flex items-center gap-1"
        >
          ← Back
        </button>
        <textarea
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
          placeholder={selectedOption === 'bug' ? 'Describe the issue...' : 'Share your idea...'}
          className="w-full h-24 p-3 rounded-xl border border-border bg-background text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
        />
        <Button 
          onClick={handleSubmit} 
          disabled={!feedback.trim()}
          className="w-full" 
          size="sm"
        >
          <Send className="w-4 h-4 mr-2" />
          Submit
        </Button>
      </motion.div>
    );
  };

  return (
    <>
      {/* Floating Button */}
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-gradient-to-r from-primary to-health-cyan text-white shadow-lg flex items-center justify-center group"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
            >
              <X className="w-6 h-6" />
            </motion.div>
          ) : (
            <motion.div
              key="open"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
            >
              <MessageCircleQuestion className="w-6 h-6" />
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Pulse ring */}
        {!isOpen && (
          <motion.div
            className="absolute inset-0 rounded-full bg-primary"
            animate={{ scale: [1, 1.3, 1], opacity: [0.5, 0, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}
      </motion.button>

      {/* Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed bottom-24 right-6 z-50 w-80 glass-card rounded-2xl shadow-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 border-b border-border bg-gradient-to-r from-primary/10 to-health-cyan/10">
              <h3 className="font-display font-semibold">Help & Feedback</h3>
              <p className="text-xs text-muted-foreground">We're here to help you</p>
            </div>

            {/* Content */}
            <div className="p-4 max-h-80 overflow-y-auto">
              <AnimatePresence mode="wait">
                {renderContent()}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default FeedbackHelp;
