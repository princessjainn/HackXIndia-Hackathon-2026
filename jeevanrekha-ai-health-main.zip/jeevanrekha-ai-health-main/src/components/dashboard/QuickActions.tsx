import { motion } from 'framer-motion';
import { MessageSquare, Search, Stethoscope, Brain, Zap } from 'lucide-react';

const actions = [
  {
    id: 'ai-chat',
    name: 'AI Health Chat',
    description: 'Chat with AI assistant',
    icon: MessageSquare,
    gradient: 'from-primary to-health-cyan',
  },
  {
    id: 'disease-search',
    name: 'Disease Search',
    description: 'Search conditions',
    icon: Search,
    gradient: 'from-orange-500 to-amber-500',
  },
  {
    id: 'symptom-checker',
    name: 'Symptom Checker',
    description: 'Check symptoms',
    icon: Stethoscope,
    gradient: 'from-green-500 to-emerald-500',
  },
  {
    id: 'mental-health',
    name: 'Mental Wellness',
    description: 'Mental support',
    icon: Brain,
    gradient: 'from-purple-500 to-violet-500',
  },
];

interface QuickActionsProps {
  onActionClick: (actionId: string) => void;
}

const QuickActions = ({ onActionClick }: QuickActionsProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-3"
    >
      <div className="flex items-center gap-2">
        <motion.div
          animate={{ rotate: [0, 360] }}
          transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
        >
          <Zap className="w-5 h-5 text-primary" />
        </motion.div>
        <h2 className="font-display text-xl font-bold">Quick Actions</h2>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {actions.map((action, index) => (
          <motion.div
            key={action.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.08 }}
            whileHover={{ y: -6, scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onActionClick(action.id)}
            className="glass-card rounded-xl p-4 cursor-pointer group relative overflow-hidden"
          >
            {/* Background gradient on hover */}
            <motion.div 
              className={`absolute inset-0 bg-gradient-to-br ${action.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}
            />
            
            <motion.div
              className={`w-10 h-10 rounded-xl bg-gradient-to-r ${action.gradient} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform shadow-lg`}
              whileHover={{ rotate: [0, -5, 5, 0] }}
            >
              <action.icon className="w-5 h-5 text-white" />
            </motion.div>
            <h3 className="font-semibold text-sm mb-0.5 group-hover:text-primary transition-colors">
              {action.name}
            </h3>
            <p className="text-xs text-muted-foreground">{action.description}</p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default QuickActions;
