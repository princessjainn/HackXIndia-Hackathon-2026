import { supabase } from "@/integrations/supabase/client";

export interface SignUpData {
  email: string;
  password: string;
  fullName: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
}

export async function signUp(data: SignUpData) {
  const { email, password, fullName, emergencyContactName, emergencyContactPhone } = data;
  
  const { data: authData, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: window.location.origin,
      data: {
        full_name: fullName,
      },
    },
  });

  if (error) throw error;

  // Update profile with emergency contact info if provided
  if (authData.user && (emergencyContactName || emergencyContactPhone)) {
    const { error: profileError } = await supabase
      .from("profiles")
      .update({
        emergency_contact_name: emergencyContactName,
        emergency_contact_phone: emergencyContactPhone,
      })
      .eq("user_id", authData.user.id);
    
    if (profileError) console.error("Failed to update profile:", profileError);
  }

  return authData;
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  if (error) throw error;
  return data;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getCurrentUser() {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}

export async function getProfile(userId: string) {
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();
  
  if (error) throw error;
  return data;
}
