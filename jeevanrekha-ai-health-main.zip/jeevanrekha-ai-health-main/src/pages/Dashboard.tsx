import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Heart,
  MessageSquare,
  Search,
  User,
  LogOut,
  Stethoscope,
  Brain,
  Menu,
  X,
  Home,
  Activity,
  ChevronLeft,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { signOut } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import AIChat from "@/components/AIChat";
import DashboardCoaches from "@/components/dashboard/DashboardCoaches";
import DashboardConditions from "@/components/dashboard/DashboardConditions";
import DashboardFeatures from "@/components/dashboard/DashboardFeatures";
import DashboardStats from "@/components/dashboard/DashboardStats";
import QuickActions from "@/components/dashboard/QuickActions";
import FeedbackHelp from "@/components/dashboard/FeedbackHelp";

type ChatType = 'general' | 'disease-search';

interface ActiveChat {
  type: ChatType;
  title: string;
  initialMessage?: string;
}

const Dashboard = () => {
  const [activeChat, setActiveChat] = useState<ActiveChat | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSignOut = async () => {
    try {
      await signOut();
      toast({ title: "Signed out successfully" });
      navigate("/");
    } catch (error) {
      toast({ variant: "destructive", title: "Failed to sign out" });
    }
  };

  const handleQuickAction = (actionId: string) => {
    switch (actionId) {
      case 'ai-chat':
        setActiveChat({ type: 'general', title: 'AI Health Chat' });
        break;
      case 'disease-search':
        setActiveChat({ type: 'disease-search', title: 'Disease Search' });
        break;
      case 'symptom-checker':
        setActiveChat({ 
          type: 'general', 
          title: 'Symptom Checker',
          initialMessage: "I want to check my symptoms. Please help me understand what might be causing them by asking me questions."
        });
        break;
      case 'mental-health':
        setActiveChat({ 
          type: 'general', 
          title: 'Mental Wellness',
          initialMessage: "I'd like to talk about my mental health and get some wellness support."
        });
        break;
    }
  };

  const handleSelectCoach = (coachId: string, coachName: string) => {
    setActiveChat({ 
      type: 'general', 
      title: coachName,
      initialMessage: `Hello! I'd like to consult with the ${coachName} about my health.`
    });
  };

  const handleSelectCondition = (conditionId: string, conditionName: string) => {
    setActiveChat({ 
      type: 'disease-search', 
      title: conditionName,
      initialMessage: `I want to learn about ${conditionName}. Please provide information about symptoms, causes, and treatment options.`
    });
  };

  const sidebarItems = [
    { id: 'dashboard', icon: Home, label: 'Dashboard', onClick: () => setActiveChat(null) },
    { id: 'ai-chat', icon: MessageSquare, label: 'AI Health Chat', onClick: () => handleQuickAction('ai-chat') },
    { id: 'disease-search', icon: Search, label: 'Disease Search', onClick: () => handleQuickAction('disease-search') },
    { id: 'symptom-checker', icon: Stethoscope, label: 'Symptom Checker', onClick: () => handleQuickAction('symptom-checker') },
    { id: 'mental-health', icon: Brain, label: 'Mental Wellness', onClick: () => handleQuickAction('mental-health') },
  ];

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <motion.aside
        initial={{ x: -280 }}
        animate={{ x: sidebarOpen ? 0 : -280 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="fixed lg:relative z-40 w-[280px] h-screen bg-card border-r border-border flex flex-col"
      >
        {/* Logo */}
        <div className="p-6 border-b border-border">
          <Link to="/" className="flex items-center gap-2 group">
            <motion.div
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.6 }}
            >
              <Heart className="w-8 h-8 text-primary" />
            </motion.div>
            <span className="font-display text-xl font-bold gradient-text">Jeevanrekha</span>
          </Link>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {sidebarItems.map((item, index) => {
            const isActive = activeChat === null ? item.id === 'dashboard' : item.id === 'ai-chat';
            return (
              <motion.button
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ x: 4 }}
                onClick={item.onClick}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  isActive
                    ? "bg-primary text-primary-foreground shadow-lg"
                    : "hover:bg-muted text-foreground"
                }`}
              >
                <item.icon className="w-5 h-5" />
                {item.label}
              </motion.button>
            );
          })}
        </nav>

        {/* User Section */}
        <div className="p-4 border-t border-border">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-3 mb-4"
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/20 to-health-cyan/20 flex items-center justify-center">
              <User className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate text-sm">{user?.email}</p>
              <p className="text-xs text-muted-foreground">Free Plan</p>
            </div>
          </motion.div>
          <Button variant="outline" onClick={handleSignOut} className="w-full" size="sm">
            <LogOut className="w-4 h-4" />
            Sign Out
          </Button>
        </div>
      </motion.aside>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-30 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 min-h-screen flex flex-col">
        {/* Top Bar */}
        <header className="sticky top-0 z-20 bg-background/80 backdrop-blur-md border-b border-border p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 rounded-lg hover:bg-muted lg:hidden"
              >
                {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
              <div>
                <motion.h1 
                  key={activeChat?.title || 'dashboard'}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="font-display text-xl font-bold flex items-center gap-2"
                >
                  {activeChat ? (
                    <>
                      <Sparkles className="w-5 h-5 text-primary" />
                      {activeChat.title}
                    </>
                  ) : (
                    <>
                      <Activity className="w-5 h-5 text-primary" />
                      Dashboard
                    </>
                  )}
                </motion.h1>
                <p className="text-sm text-muted-foreground">
                  {activeChat ? "Chat with AI" : "Welcome back!"}
                </p>
              </div>
            </div>
            {activeChat && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <Button variant="ghost" onClick={() => setActiveChat(null)} size="sm">
                  <ChevronLeft className="w-4 h-4 mr-1" />
                  Back
                </Button>
              </motion.div>
            )}
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          <AnimatePresence mode="wait">
            {activeChat ? (
              <motion.div
                key="chat"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="h-[calc(100vh-80px)] p-4"
              >
                <div className="h-full bg-card rounded-2xl border border-border overflow-hidden shadow-lg">
                  <AIChat type={activeChat.type} initialMessage={activeChat.initialMessage} />
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="p-6 space-y-8"
              >
                {/* Stats Row */}
                <DashboardStats />

                {/* Quick Actions */}
                <QuickActions onActionClick={handleQuickAction} />

                {/* AI Coaches Section */}
                <DashboardCoaches onSelectCoach={handleSelectCoach} />

                {/* Health Conditions Section */}
                <DashboardConditions onSelectCondition={handleSelectCondition} />

                {/* Features Section */}
                <DashboardFeatures />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Floating Feedback/Help Button */}
      <FeedbackHelp />
    </div>
  );
};

export default Dashboard;
