import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Heart, Lock, Mail, User, Phone, Shield, ArrowRight, Check } from "lucide-react";
import { signUp } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

const steps = [
  { id: 1, name: "Account", icon: User },
  { id: 2, name: "Consent", icon: Shield },
  { id: 3, name: "Profile", icon: Check },
];

const Register = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    emergencyContactName: "",
    emergencyContactPhone: "",
    consent: false,
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const updateFormData = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (currentStep === 1) {
      if (!formData.fullName || !formData.email || !formData.password) {
        toast({
          variant: "destructive",
          title: "Missing fields",
          description: "Please fill in all required fields.",
        });
        return;
      }
      if (formData.password !== formData.confirmPassword) {
        toast({
          variant: "destructive",
          title: "Passwords don't match",
          description: "Please ensure both passwords match.",
        });
        return;
      }
      if (formData.password.length < 6) {
        toast({
          variant: "destructive",
          title: "Password too short",
          description: "Password must be at least 6 characters.",
        });
        return;
      }
    }
    if (currentStep === 2 && !formData.consent) {
      toast({
        variant: "destructive",
        title: "Consent required",
        description: "Please agree to the terms to continue.",
      });
      return;
    }
    setCurrentStep((prev) => prev + 1);
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await signUp({
        email: formData.email,
        password: formData.password,
        fullName: formData.fullName,
        emergencyContactName: formData.emergencyContactName,
        emergencyContactPhone: formData.emergencyContactPhone,
      });
      toast({
        title: "Account created!",
        description: "Welcome to Jeevanrekha. Your health journey begins now.",
      });
      navigate("/dashboard");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: error.message || "Something went wrong",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 to-background">
      {/* Top Bar */}
      <div className="h-2 bg-gradient-to-r from-primary to-health-cyan" />

      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-xl mx-auto"
        >
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="font-display text-4xl font-bold mb-2">Create Your Account</h1>
            <p className="text-muted-foreground">Join Jeevanrekha for personalized AI health guidance</p>
          </div>

          {/* Progress Steps */}
          <div className="flex items-center justify-center gap-4 mb-10">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all ${
                    currentStep >= step.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {currentStep > step.id ? <Check className="w-5 h-5" /> : step.id}
                </div>
                <span
                  className={`ml-2 font-medium ${
                    currentStep >= step.id ? "text-primary" : "text-muted-foreground"
                  }`}
                >
                  {step.name}
                </span>
                {index < steps.length - 1 && (
                  <div
                    className={`w-16 h-0.5 mx-4 ${
                      currentStep > step.id ? "bg-primary" : "bg-muted"
                    }`}
                  />
                )}
              </div>
            ))}
          </div>

          {/* Form Card */}
          <div className="glass-card rounded-2xl p-8">
            {currentStep === 1 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <div className="flex items-center gap-2 mb-6">
                  <Lock className="w-5 h-5 text-primary" />
                  <h2 className="font-display text-xl font-semibold">Secure Account Creation</h2>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name *</Label>
                  <Input
                    id="fullName"
                    placeholder="John Doe"
                    value={formData.fullName}
                    onChange={(e) => updateFormData("fullName", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="john@example.com"
                    value={formData.email}
                    onChange={(e) => updateFormData("email", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password *</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={(e) => updateFormData("password", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm Password *</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="••••••••"
                    value={formData.confirmPassword}
                    onChange={(e) => updateFormData("confirmPassword", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="emergencyName">Emergency Contact Name</Label>
                  <Input
                    id="emergencyName"
                    placeholder="Jane Doe"
                    value={formData.emergencyContactName}
                    onChange={(e) => updateFormData("emergencyContactName", e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="emergencyPhone">Emergency Contact Phone</Label>
                  <Input
                    id="emergencyPhone"
                    placeholder="+1 (555) 123-4567"
                    value={formData.emergencyContactPhone}
                    onChange={(e) => updateFormData("emergencyContactPhone", e.target.value)}
                  />
                </div>

                <Button onClick={handleNext} variant="hero" size="lg" className="w-full">
                  Continue to Consent
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </motion.div>
            )}

            {currentStep === 2 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <div className="flex items-center gap-2 mb-6">
                  <Shield className="w-5 h-5 text-primary" />
                  <h2 className="font-display text-xl font-semibold">Terms & Privacy</h2>
                </div>

                <div className="bg-muted/50 rounded-xl p-6 text-sm text-muted-foreground space-y-4">
                  <p>
                    <strong>By creating an account, you agree to:</strong>
                  </p>
                  <ul className="list-disc list-inside space-y-2">
                    <li>Our Terms of Service and Privacy Policy</li>
                    <li>Receive health-related information and recommendations</li>
                    <li>Understanding that AI guidance is not a substitute for professional medical advice</li>
                    <li>Your data being securely stored and processed</li>
                  </ul>
                </div>

                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.consent}
                    onChange={(e) => updateFormData("consent", e.target.checked)}
                    className="mt-1 w-5 h-5 rounded border-primary text-primary focus:ring-primary"
                  />
                  <span className="text-sm">
                    I have read and agree to the Terms of Service and Privacy Policy. I understand that
                    Jeevanrekha provides AI-powered health guidance and is not a substitute for professional
                    medical care.
                  </span>
                </label>

                <div className="flex gap-4">
                  <Button variant="outline" onClick={() => setCurrentStep(1)} className="flex-1">
                    Back
                  </Button>
                  <Button onClick={handleNext} variant="hero" className="flex-1">
                    Continue
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </div>
              </motion.div>
            )}

            {currentStep === 3 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6 text-center"
              >
                <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                  <Check className="w-10 h-10 text-primary" />
                </div>

                <h2 className="font-display text-2xl font-semibold">Ready to Join!</h2>
                <p className="text-muted-foreground">
                  Click below to create your account and start your personalized health journey with
                  Jeevanrekha AI.
                </p>

                <div className="bg-muted/50 rounded-xl p-4 text-left">
                  <p className="text-sm">
                    <strong>Account Details:</strong>
                  </p>
                  <p className="text-sm text-muted-foreground">{formData.fullName}</p>
                  <p className="text-sm text-muted-foreground">{formData.email}</p>
                </div>

                <div className="flex gap-4">
                  <Button variant="outline" onClick={() => setCurrentStep(2)} className="flex-1">
                    Back
                  </Button>
                  <Button
                    onClick={handleSubmit}
                    variant="hero"
                    className="flex-1"
                    disabled={loading}
                  >
                    {loading ? "Creating Account..." : "Create Account"}
                  </Button>
                </div>
              </motion.div>
            )}
          </div>

          {/* Footer */}
          <p className="text-center mt-6 text-muted-foreground">
            Already have an account?{" "}
            <Link to="/login" className="text-primary font-medium hover:underline">
              Sign in
            </Link>
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default Register;
